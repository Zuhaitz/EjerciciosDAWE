# A really, really simple offline page using Service Workers

If you'd like a simple step-by-step guide to the code in this repo, please head over to my blog at [deanhume.com](http://deanhume.com/Home/BlogPost/create-a-really--really-simple-offline-page-using-service-workers/10135)

![Offline web page](http://a43d55f6a02c4be185ce-9cfa4cf7c673a59966ad8296f4c88804.r44.cf3.rackcdn.com/Service-Worker-Offline/custom-offline-page.jpg)
